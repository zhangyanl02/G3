
int area( char* angfile, char* scafile, char* datasrc,char* lyrname,int uselyrname,int lyrno, char *wfile, int useOutlets, int usew, int contcheck);
