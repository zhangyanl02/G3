#include"linearpart.h"
bool pointsToMe(long col, long row, long ncol, long nrow, tdpartition *dirData);
//int netsetup(char *pfile,char *srcfile,char *ordfile,char *ad8file,char *elevfile,char *treefile, char *coordfile, char *outletshapefile,char *wfile, char *shapename, int useOutlets, long usetrace, long idnodes);
