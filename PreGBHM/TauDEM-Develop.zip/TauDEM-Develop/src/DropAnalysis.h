#include "linearpart.h"


int dropan(char *areafile, char *dirfile, char *elevfile, char *ssafile, char *dropfile,
                           char *outletfile, float threshmin, float threshmax, int nthresh, int steptype,
                           float *threshopt);

